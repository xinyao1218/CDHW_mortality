# version of the climate_indices package, should match with setup.py
__version__ = "1.0.9"
